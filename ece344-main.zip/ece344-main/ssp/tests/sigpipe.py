#!/usr/bin/env python3

from base import test

expected = [
    '    PID CMD STATUS\n',
    '        cat 141\n',
]

test(expected)
