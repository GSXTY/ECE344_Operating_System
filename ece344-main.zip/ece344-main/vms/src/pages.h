#ifndef PAGES_H
#define PAGES_H

#define MAX_PAGES 256
#define NUM_PTE_ENTRIES 512

void check_page_aligned(void* pointer);

#endif

