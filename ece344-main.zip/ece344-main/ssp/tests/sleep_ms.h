#ifndef SLEEP_MS
#define SLEEP_MS

#include <stdint.h>

void sleep_ms(uint32_t milliseconds);

#endif
